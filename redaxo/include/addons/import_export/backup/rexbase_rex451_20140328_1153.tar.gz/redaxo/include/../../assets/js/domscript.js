/*
basecondition ~ domscript.js v3.2
copyright 2014 ~ Joachim Doerr, hello@basecondition.com
licensed under MIT or GPLv3
*/

!function ($) {
  
}(window.jQuery)